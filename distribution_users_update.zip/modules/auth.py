from functools import wraps
import sqlite3
from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from werkzeug.security import generate_password_hash, check_password_hash
from database import get_connection
from modules.permissions import sections_for_system, section_groups_for_system, section_labels_for_system

auth = Blueprint("auth", __name__)

# Distribution (and Manufacturing) use two roles: "admin" = full access, "staff" = restricted to
# whatever is ticked on their permissions grid (Users -> Edit Grid).
ROLES = ["admin", "staff"]
PROJECT_ROLES = ["admin", "user", "external"]
HIRING_ROLES = ["admin", "recruiter", "hiring_manager", "viewer"]
DELIVERY_ROLES = ["admin", "dispatcher", "driver"]

# ============================================
# ACCESS CONTROL HELPERS
# ============================================

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("user_id"):
            return redirect(url_for("auth.login", next=request.path))
        return view(*args, **kwargs)
    return wrapped

def roles_required(*roles):
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if not session.get("user_id"):
                return redirect(url_for("auth.login", next=request.path))
            if session.get("role") != "admin" and session.get("role") not in roles:
                flash("You don't have permission to access that.", "danger")
                return redirect(url_for("index"))
            return view(*args, **kwargs)
        return wrapped
    return decorator

def require_roles(*roles):
    """Blueprint-level guard: attach with `blueprint.before_request(require_roles(...))`."""
    def check():
        if not session.get("user_id"):
            return redirect(url_for("auth.login", next=request.path))
        if session.get("role") != "admin" and session.get("role") not in roles:
            flash("You don't have permission to access that section.", "danger")
            return redirect(url_for("index"))
    return check


def require_login():
    """Blueprint-level guard: just checks you're logged in — no role restriction yet."""
    if not session.get("user_id"):
        return redirect(url_for("auth.login", next=request.path))


# ============================================
# LOGIN / LOGOUT
# ============================================

def require_system(system_name):
    """Blueprint-level guard: must be logged in AND logged into this specific system."""
    def check():
        if not session.get("user_id"):
            return redirect(url_for("auth.login", system=system_name, next=request.path))
        if session.get("system") != system_name:
            flash("That section belongs to a different login.", "danger")
            return redirect(url_for("auth.login", system=system_name))
    return check


def system_required(system_name):
    """Route decorator version of require_system, for routes defined directly in app.py."""
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if not session.get("user_id"):
                return redirect(url_for("auth.login", system=system_name, next=request.path))
            if session.get("system") != system_name:
                flash("That section belongs to a different login.", "danger")
                return redirect(url_for("auth.login", system=system_name))
            return view(*args, **kwargs)
        return wrapped
    return decorator


@auth.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"].strip()
        password = request.form["password"]
        system = request.form["system"]
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT * FROM users WHERE username = ? AND system = ?",
            (username, system),
        )
        user = cursor.fetchone()
        conn.close()
        if not user or not check_password_hash(user["password_hash"], password):
            flash("Invalid username or password.", "danger")
            return redirect(url_for("auth.login", system=system))
        if not user["is_active"]:
            flash("This account has been deactivated.", "danger")
            return redirect(url_for("auth.login", system=system))
        if user["system"] != system:
            flash("This login isn't set up for that system.", "danger")
            return redirect(url_for("auth.login", system=system))
        session.clear()
        session["user_id"] = user["id"]
        session["username"] = user["username"]
        session["full_name"] = user["full_name"] or user["username"]
        session["role"] = user["role"]
        session["system"] = user["system"]
        flash(f"Welcome back, {session['full_name']}!", "success")
        next_url = request.args.get("next")
        if next_url:
            return redirect(next_url)
        if system == "manufacturing":
            return redirect(url_for("manufacturing.index"))
        if system == "projects":
            return redirect(url_for("projects.index"))
        if system == "hiring":
            return redirect(url_for("hiring.index"))
        if system == "delivery":
            return redirect(url_for("delivery.index"))
        return redirect(url_for("index"))

    system = request.args.get("system")
    if not system:
        return render_template("auth/login_chooser.html")
    return render_template("auth/login.html", system=system)

@auth.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("auth.login"))

# ============================================
# USER MANAGEMENT (admin only)
# ============================================

@auth.route("/users")
@roles_required("admin")
def users_list():
    system = session.get("system", "distribution")
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE system = ? ORDER BY username", (system,))
    users = cursor.fetchall()
    cursor.execute("SELECT COUNT(*) FROM users WHERE system = 'projects'")
    projects_setup_available = cursor.fetchone()[0] == 0
    cursor.execute("SELECT COUNT(*) FROM users WHERE system = 'hiring'")
    hiring_setup_available = cursor.fetchone()[0] == 0
    cursor.execute("SELECT COUNT(*) FROM users WHERE system = 'delivery'")
    delivery_setup_available = cursor.fetchone()[0] == 0
    conn.close()
    template = "projects/users.html" if system == "projects" else "auth/users.html"
    roles = (
        PROJECT_ROLES if system == "projects"
        else HIRING_ROLES if system == "hiring"
        else DELIVERY_ROLES if system == "delivery"
        else ROLES
    )
    return render_template(template, users=users, roles=roles, system=system,
                           projects_setup_available=projects_setup_available,
                           hiring_setup_available=hiring_setup_available,
                           delivery_setup_available=delivery_setup_available)

@auth.route("/users/setup-projects", methods=["GET", "POST"])
@roles_required("admin")
def setup_projects():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM users WHERE system = 'projects'")
    already_setup = cursor.fetchone()[0] > 0
    if already_setup:
        conn.close()
        flash("The Projects portal already has a user. Add further users from that portal.", "info")
        return redirect(url_for("auth.users_list"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        full_name = request.form.get("full_name", "").strip()
        password = request.form.get("password", "")
        if not username or len(password) < 8:
            conn.close()
            flash("Enter a username and a password with at least 8 characters.", "danger")
            return render_template("auth/project_setup.html")
        try:
            cursor.execute(
                "INSERT INTO users (username, password_hash, full_name, role, system) VALUES (?,?,?,?,?)",
                (username, generate_password_hash(password), full_name, "admin", "projects")
            )
            conn.commit()
        except Exception:
            conn.close()
            flash("That username is already taken.", "danger")
            return render_template("auth/project_setup.html")
        conn.close()
        flash("Projects administrator created. Sign in to Projects with those credentials.", "success")
        return redirect(url_for("auth.users_list"))

    conn.close()
    return render_template("auth/project_setup.html")

@auth.route("/users/setup-hiring", methods=["GET", "POST"])
@roles_required("admin")
def setup_hiring():
    if session.get("system") not in ("distribution", "hiring"):
        flash("Set up Hiring from an administrator account.", "danger")
        return redirect(url_for("auth.users_list"))
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM users WHERE system = 'hiring'")
    if cursor.fetchone()[0] > 0:
        conn.close()
        flash("The Hiring portal already has a user. Add further users from that portal.", "info")
        return redirect(url_for("auth.users_list"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        full_name = request.form.get("full_name", "").strip()
        password = request.form.get("password", "")
        if not username or len(password) < 8:
            conn.close()
            flash("Enter a username and a password with at least 8 characters.", "danger")
            return render_template("auth/hiring_setup.html")
        try:
            cursor.execute(
                "INSERT INTO users (username, password_hash, full_name, role, system) VALUES (?,?,?,?,?)",
                (username, generate_password_hash(password), full_name, "admin", "hiring")
            )
            conn.commit()
        except Exception:
            conn.close()
            flash("That username is already taken.", "danger")
            return render_template("auth/hiring_setup.html")
        conn.close()
        flash("Hiring administrator created. Sign in to Hiring with those credentials.", "success")
        return redirect(url_for("auth.users_list"))

    conn.close()
    return render_template("auth/hiring_setup.html")


@auth.route("/users/setup-delivery", methods=["GET", "POST"])
@roles_required("admin")
def setup_delivery():
    if session.get("system") not in ("distribution", "delivery"):
        flash("Set up Delivery from an administrator account.", "danger")
        return redirect(url_for("auth.users_list"))
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM users WHERE system = 'delivery'")
    if cursor.fetchone()[0] > 0:
        conn.close()
        flash("The Delivery portal already has a user. Add further users from that portal.", "info")
        return redirect(url_for("auth.users_list"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        full_name = request.form.get("full_name", "").strip()
        password = request.form.get("password", "")
        if not username or len(password) < 8:
            conn.close()
            flash("Enter a username and a password with at least 8 characters.", "danger")
            return render_template("auth/delivery_setup.html")
        try:
            cursor.execute(
                "INSERT INTO users (username, password_hash, full_name, role, system) VALUES (?,?,?,?,?)",
                (username, generate_password_hash(password), full_name, "admin", "delivery")
            )
            conn.commit()
        except Exception:
            conn.close()
            flash("That username is already taken.", "danger")
            return render_template("auth/delivery_setup.html")
        conn.close()
        flash("Delivery administrator created. Sign in to Delivery with those credentials.", "success")
        return redirect(url_for("auth.users_list"))

    conn.close()
    return render_template("auth/delivery_setup.html")

@auth.route("/users/add", methods=["GET", "POST"])
@roles_required("admin")
def add_user():
    if request.method == "POST":
        username = request.form["username"].strip()
        full_name = request.form.get("full_name")
        role = request.form.get("role") or "staff"
        password = request.form["password"]
        system = session.get("system", "distribution")
        if system == "projects":
            role = role if role in PROJECT_ROLES else "user"
        elif system == "hiring":
            role = role if role in HIRING_ROLES else "recruiter"
        elif system == "delivery":
            role = role if role in DELIVERY_ROLES else "driver"
        else:
            role = role if role in ROLES else "staff"
        conn = get_connection()
        cursor = conn.cursor()
        new_id = None
        try:
            cursor.execute(
                "INSERT INTO users (username, password_hash, full_name, role, system) VALUES (?,?,?,?,?)",
                (username, generate_password_hash(password), full_name, role, system)
            )
            new_id = cursor.lastrowid
            conn.commit()
            flash("User added successfully!", "success")
        except Exception:
            flash("That username is already taken.", "danger")
        conn.close()
        if new_id and system == "distribution" and role != "admin":
            flash("Now tick what this user is allowed to access.", "info")
            return redirect(url_for("auth.user_permissions", user_id=new_id))
        return redirect(url_for("auth.users_list"))
    system = session.get("system", "distribution")
    if system == "projects":
        return render_template("projects/user_form.html", system=system, roles=PROJECT_ROLES, editing=False)
    roles = DELIVERY_ROLES if system == "delivery" else HIRING_ROLES if system == "hiring" else ROLES
    return render_template("auth/users.html", users=[], roles=roles, system=system)

@auth.route("/users/edit/<int:user_id>", methods=["GET", "POST"])
@roles_required("admin")
def edit_user(user_id):
    system = session.get("system", "distribution")
    conn = get_connection()
    cursor = conn.cursor()
    if request.method == "POST":
        full_name = request.form.get("full_name")
        role = request.form.get("role") or "staff"
        if system == "projects":
            role = role if role in PROJECT_ROLES else "user"
        elif system == "hiring":
            role = role if role in HIRING_ROLES else "recruiter"
        elif system == "delivery":
            role = role if role in DELIVERY_ROLES else "driver"
        else:
            role = role if role in ROLES else "staff"
        username = request.form.get("username", "").strip()
        if system == "delivery" and not username:
            conn.close()
            flash("Username is required.", "danger")
            return redirect(url_for("auth.users_list"))
        is_active = 1 if request.form.get("is_active") else 0
        password = request.form.get("password")
        try:
            if system == "delivery" and password:
                cursor.execute(
                    """UPDATE users SET username=?, full_name=?, role=?, is_active=?, password_hash=?
                       WHERE id=? AND system=?""",
                    (username, full_name, role, is_active, generate_password_hash(password), user_id, system)
                )
            elif system == "delivery":
                cursor.execute(
                    """UPDATE users SET username=?, full_name=?, role=?, is_active=?
                       WHERE id=? AND system=?""",
                    (username, full_name, role, is_active, user_id, system)
                )
            elif password:
                cursor.execute(
                    "UPDATE users SET full_name=?, role=?, is_active=?, password_hash=? WHERE id=? AND system=?",
                    (full_name, role, is_active, generate_password_hash(password), user_id, system)
                )
            else:
                cursor.execute(
                    "UPDATE users SET full_name=?, role=?, is_active=? WHERE id=? AND system=?",
                    (full_name, role, is_active, user_id, system)
                )
        except sqlite3.IntegrityError:
            conn.rollback()
            conn.close()
            flash("That username is already taken in this system.", "danger")
            return redirect(url_for("auth.users_list"))
        conn.commit()
        conn.close()
        flash("User updated successfully!", "success")
        return redirect(url_for("auth.users_list"))
    cursor.execute("SELECT * FROM users WHERE id = ? AND system = ?", (user_id, system))
    user = cursor.fetchone()
    conn.close()
    if not user:
        flash("User not found.", "danger")
        return redirect(url_for("auth.users_list"))
    if system == "projects":
        return render_template("projects/user_form.html", user=user, roles=PROJECT_ROLES, editing=True, system=system)
    roles = DELIVERY_ROLES if system == "delivery" else HIRING_ROLES if system == "hiring" else ROLES
    return render_template("auth/users.html", users=[], user=user, roles=roles, editing=True, system=system)

# ============================================
# PERMISSIONS GRID (Distribution) - same idea as Manufacturing's "Edit Grid"
# ============================================

@auth.route("/users/<int:user_id>/permissions", methods=["GET", "POST"])
@roles_required("admin")
def user_permissions(user_id):
    system = session.get("system", "distribution")
    if system != "distribution":
        flash("Permission grids are managed from the Distribution users page.", "danger")
        return redirect(url_for("auth.users_list"))
    sections = sections_for_system(system)
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE id = ? AND system = ?", (user_id, system))
    user = cursor.fetchone()
    if not user:
        conn.close()
        flash("User not found.", "danger")
        return redirect(url_for("auth.users_list"))
    if user["role"] == "admin":
        conn.close()
        flash("Admins always have full access - they don't need a permissions grid.", "info")
        return redirect(url_for("auth.users_list"))

    if request.method == "POST":
        keys = [key for key, _label in sections]
        placeholders = ",".join("?" * len(keys))
        cursor.execute(
            f"DELETE FROM permissions WHERE user_id = ? AND section IN ({placeholders})",
            (user_id, *keys),
        )
        for section in keys:
            can_view = 1 if request.form.get(f"view_{section}") else 0
            can_create = 1 if request.form.get(f"create_{section}") else 0
            can_edit = 1 if request.form.get(f"edit_{section}") else 0
            can_delete = 1 if request.form.get(f"delete_{section}") else 0
            if can_view or can_create or can_edit or can_delete:
                cursor.execute(
                    "INSERT INTO permissions (user_id, section, can_view, can_create, can_edit, can_delete) VALUES (?,?,?,?,?,?)",
                    (user_id, section, can_view, can_create, can_edit, can_delete),
                )
        conn.commit()
        conn.close()
        flash("Permissions updated successfully!", "success")
        return redirect(url_for("auth.users_list"))

    cursor.execute(
        "SELECT section, can_view, can_create, can_edit, can_delete FROM permissions WHERE user_id = ?",
        (user_id,),
    )
    existing = {row["section"]: row for row in cursor.fetchall()}
    conn.close()
    return render_template("auth/user_permissions.html", user=user,
                           groups=section_groups_for_system(system),
                           labels=section_labels_for_system(system), existing=existing)

@auth.route("/users/delete/<int:user_id>")
@roles_required("admin")
def delete_user(user_id):
    if user_id == session.get("user_id"):
        flash("You can't delete your own account while logged in.", "danger")
        return redirect(url_for("auth.users_list"))
    system = session.get("system", "distribution")
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM users WHERE id = ? AND system = ?", (user_id, system))
    conn.commit()
    conn.close()
    flash("User deleted successfully!", "danger")
    return redirect(url_for("auth.users_list"))
